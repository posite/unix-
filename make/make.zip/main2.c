#include "ipc.h"
#include <stdio.h>

int main(){
        printf("msq test start \n\n");
        msgqtest();
        printf("\nmsq test end \n");

        return 0;
}
