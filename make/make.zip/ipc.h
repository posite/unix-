void shmtest();
void pipetest();
void msgqtest();
