#include "ipc.h"
#include <stdio.h>

int main(){
        printf("pipe start \n\n");
        pipetest();
        printf("\npipe end \n");

        return 0;
}
